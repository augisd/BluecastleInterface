// toggle between hiding and showing dropdown content
function drop(id,id2) {
	document.getElementById(id).classList.toggle("show");
	document.getElementById(id2).classList.toggle("fa-caret-up");
}
